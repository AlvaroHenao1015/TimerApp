//
//  configurationBrain.swift
//  TimerApp
//
//  Created by Alvaro Henao on 23/11/23.
//

import SwiftUI

protocol configurationBrainProtocol: AnyObject {
    func setViewController(_ viewController: configurationViewControllerProtocol)
    func processContinueButtonPressed(with timeoutText: String)
    func getTimeout() -> Int
    
}

class configurationBrain {
    private weak  var viewController: configurationViewControllerProtocol?
    var timeout = 0
}

extension configurationBrain: configurationBrainProtocol {
    func setViewController(_ viewController: configurationViewControllerProtocol) {
        self.viewController = viewController 
    }
    
    func processContinueButtonPressed(with timeoutText: String) {
        guard let viewController = viewController  else {
            return
        }
        if let timeout = Int(timeoutText){
            self.timeout = timeout
            viewController.navigateTowardsTimer()
        }else {
            viewController.presentError(with: "Timeout vacío")
        }
        viewController.navigateTowardsTimer()
    }
    
    func getTimeout() -> Int {
        timeout
    }
}
