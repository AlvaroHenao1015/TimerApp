//
//  ConfigurationViewController.swift
//  TimerApp
//
//  Created by Alvaro Henao on 21/11/23.
//

import UIKit

protocol configurationViewControllerProtocol: AnyObject {
    func navigateTowardsTimer()
    func presentError(with message: String)
}

class ConfigurationViewController: UIViewController{
    
    struct Constant{
        static let segueId = "ToTimer"
    }
    
    @IBOutlet weak var timeoutTextField: UITextField!
    
    private let brain: configurationBrainProtocol = configurationBrain()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        brain.setViewController(self)
    }
    
    @IBAction func onContinueButtonPressed() {
        guard let timeoutText = timeoutTextField.text else{
             return
        }
        brain.processContinueButtonPressed(with: timeoutText)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let timerViewController = segue.destination as? TimerViewController else {
            return
        }
        let timeout = brain.getTimeout()
        timerViewController.setTimeout(timeout)
    }
}

extension ConfigurationViewController: configurationViewControllerProtocol {
    func navigateTowardsTimer() {
        performSegue(withIdentifier: Constant.segueId, sender: self)
    }
    
    func presentError(with message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction =  UIAlertAction(title: "OK", style: .default)
        present(alert, animated: true)
    }
}
