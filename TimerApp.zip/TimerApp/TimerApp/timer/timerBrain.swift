//
//  timerBrain.swift
//  TimerApp
//
//  Created by Alvaro Henao on 23/11/23.
//

import SwiftUI

protocol TimerBrainProtocol: AnyObject {
    func setViewController(_ viewController: TimerViewControllerProtocol)
    func setTimeout(_ timeout: Int)
    func processViewDidLoad()
}

class TimerBrain {
    
    private var timeout: Int?
    private weak  var viewController: TimerViewControllerProtocol?
    private var currentTime = 0
    private let timeRemainingCalculator  = TimeRemainingCalculator()
    private let timeRemainingPresenter  = TimeRemainingPresenter()
    private let timeProgressCalculator  = TimeProgressCalculator()
    private let timerManager = TimerManager()
    
    func updateUI() {
        updateProgess()
        updateTimeRemaining()
    }
    
    func updateProgess() {
        guard let timeout = timeout else {
            return
        }
        
        guard let viewController = viewController else {
            return
        }
        
        let progress = timeProgressCalculator.getProgress(currentTime: currentTime, timeout: timeout)
        viewController.setProgress(progress)
    }
    
    func updateTimeRemaining() {
        guard let timeout = timeout else {
            return
        }
        
        guard let viewController = viewController else {
            return
        }
        
        let timeRemaining = timeRemainingCalculator.getTimeRemaining(timeout: timeout, currentTime: currentTime)
        let timeRemainingText = timeRemainingPresenter.convertToText(timeRemaining: timeRemaining)
        
        viewController.setTimeRemaining( timeRemainingText: timeRemainingText )
    }
    
    func startTimer() {
        timerManager.setDelegate(self)
        timerManager.startTimer()
    }
}

extension TimerBrain: TimerManagerDelegate {
    func processTimerTick() {
        guard let timeout = timeout else {
            return
        }
        
        currentTime += 1
        
        updateUI()
        
        if currentTime >= timeout {
            timerManager.stopTimer()
        }
    } 
}
 
extension TimerBrain: TimerBrainProtocol {
    func setViewController(_ viewController: TimerViewControllerProtocol) {
        self.viewController = viewController
    }
    
    func setTimeout(_ timeout: Int) {
        self.timeout = timeout
    }
    
    func processViewDidLoad() {
        updateUI()
        startTimer()
    }
}
