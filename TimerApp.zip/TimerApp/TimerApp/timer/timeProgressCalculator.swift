//
//  timeProgressCalculator.swift
//  TimerApp
//
//  Created by Alvaro Henao on 23/11/23.
//

import SwiftUI

class TimeProgressCalculator {
    func getProgress(currentTime: Int, timeout: Int) -> Float {
        return Float(currentTime) / Float(timeout)
    }
}
