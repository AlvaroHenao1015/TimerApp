//
//  TimerViewController.swift
//  TimerApp
//
//  Created by Alvaro Henao on 21/11/23.
//

import UIKit

protocol TimerViewControllerProtocol: AnyObject {
    func setTimeRemaining(timeRemainingText: String)
    func setProgress(_ progress: Float)
}

class TimerViewController: UIViewController{
    @IBOutlet weak var timeoutLabel: UILabel!
    @IBOutlet weak var timeoutProgress: UIProgressView!
    
    private let brain: TimerBrainProtocol = TimerBrain()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        brain.setViewController(self)
        brain.processViewDidLoad()
    }
    
    func setTimeout(_ timeout: Int) {
        brain.setTimeout(timeout)
    }
}

extension TimerViewController: TimerViewControllerProtocol {
    func setTimeRemaining(timeRemainingText: String) {
        timeoutLabel.text = timeRemainingText
    }
    
    func setProgress(_ progress: Float) {
        timeoutProgress.progress = progress
    }
}
