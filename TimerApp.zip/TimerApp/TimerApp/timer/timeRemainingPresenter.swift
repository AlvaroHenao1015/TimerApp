//
//  timeRemainingPresenter.swift
//  TimerApp
//
//  Created by Alvaro Henao on 23/11/23.
//

import SwiftUI

class TimeRemainingPresenter {
    func convertToText(timeRemaining: timeRemaining) -> String {
        let minutesAsString =  "\(timeRemaining.minutes)"
        let secondsAsString = "\(timeRemaining.seconds < 10 ? "0" : "")\(timeRemaining.seconds)"
        return "\(minutesAsString): \(secondsAsString)"
    }
}
