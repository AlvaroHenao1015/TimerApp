//
//  timerManager.swift
//  TimerApp
//
//  Created by Alvaro Henao on 23/11/23.
//

import SwiftUI

protocol TimerManagerDelegate: AnyObject {
    func processTimerTick()
}

class TimerManager {
    private weak var delegate: TimerManagerDelegate?
    private var timer: Timer?
    
    func setDelegate(_ brain: TimerManagerDelegate) {
        self.delegate = brain
    }
    
    func startTimer(){
        timer = Timer.scheduledTimer(
            timeInterval: 1.0 ,
            target: self,
            selector: #selector(processTick),
            userInfo: nil,
            repeats: true)
    }
    
    @objc private func processTick(){
        guard let delegate = delegate else {
            return
        }
        delegate.processTimerTick()
    }
    
    func stopTimer() {
        timer?.invalidate()
        timer = nil 
    }
}
