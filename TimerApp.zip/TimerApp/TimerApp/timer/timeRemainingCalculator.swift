//
//  timeRemainingCalculator.swift
//  TimerApp
//
//  Created by Alvaro Henao on 23/11/23.
//

import SwiftUI

struct timeRemaining {
    let seconds: Int
    let minutes: Int
}

class TimeRemainingCalculator {
    func getTimeRemaining(timeout: Int, currentTime: Int) -> timeRemaining{
        let secondsLeft = Float(timeout - currentTime)
        let minutes = Int(secondsLeft / 60.0)
        let seconds = Int(secondsLeft)  - minutes * 60
        return timeRemaining(seconds: seconds, minutes: minutes)
    }
}
